package com.mycompany.uf3_hibernate;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class LeerProducto {

    public static void main(String[] args) {
        // Cargar la configuración desde hibernate.cfg.xml
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");

        // Crear la sesión de fábrica (SessionFactory)
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Abrir una sesión de Hibernate
        try (Session session = sessionFactory.openSession()) {
            // Iniciar una transacción
            Transaction tx = session.beginTransaction();

            Scanner scanner = new Scanner(System.in);
            System.out.println("Introduce el ID del producto: ");
            long id = scanner.nextInt();

            // Obtener el producto por su ID
            Producto producto = session.get(Producto.class, id);

            // Verificar si el producto existe
            if (producto != null) {
                System.out.println("Información del producto con ID " + id + ":");
                System.out.println(producto);
            } else {
                System.out.println("No se encontró ningún producto con el ID proporcionado.");
            }

            // Commit de la transacción
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Cerrar la sesión de fábrica al finalizar
            sessionFactory.close();
        }
    }
}
