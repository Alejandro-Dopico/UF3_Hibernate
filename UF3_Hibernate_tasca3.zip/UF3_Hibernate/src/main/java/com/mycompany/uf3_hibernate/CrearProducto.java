/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.uf3_hibernate;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CrearProducto {

    public static void main(String[] args) {
        // Cargar la configuración desde hibernate.cfg.xml
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");

        // Crear la sesión de fábrica (SessionFactory)
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Abrir una sesión de Hibernate
        try (Session session = sessionFactory.openSession()) {

            Transaction tx = session.beginTransaction();
              
            Scanner scanner = new Scanner(System.in);  
            
            System.out.println("Introduce el nombre del producto: ");
            String name = scanner.next(); 
            System.out.println("El nombre del producto es " + name); 
            
            System.out.println("Introduce el precio: ");
            double precio = scanner.nextDouble(); 
            System.out.println("Introduce el precio: " + precio); 
            
            // Crear un objeto Producto y guardarlo en la base de datos
            Producto producto = new Producto(name, precio);
            session.save(producto);

            tx.commit();

            // Leer el producto recién guardado desde la base de datos
            Producto productoGuardado = session.get(Producto.class, producto.getId());
            System.out.println("Producto guardado: " + productoGuardado);

        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Cerrar la sesión de fábrica al finalizar
            sessionFactory.close();
        }
    }
}
