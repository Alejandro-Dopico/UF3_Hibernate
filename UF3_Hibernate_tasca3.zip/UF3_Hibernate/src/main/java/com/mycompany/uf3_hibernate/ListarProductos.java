package com.mycompany.uf3_hibernate;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class ListarProductos {

    public static void main(String[] args) {
        // Cargar la configuración desde hibernate.cfg.xml
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");

        // Crear la sesión de fábrica (SessionFactory)
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Abrir una sesión de Hibernate
        try (Session session = sessionFactory.openSession()) {
            // Iniciar una transacción
            Transaction tx = session.beginTransaction();

            // Consultar todos los productos
            List<Producto> productos = session.createQuery("FROM Producto", Producto.class).list();

            // Imprimir los productos
            System.out.println("Lista de productos:");
            for (Producto producto : productos) {
                System.out.println(producto);
            }

            // Commit de la transacción
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Cerrar la sesión de fábrica al finalizar
            sessionFactory.close();
        }
    }
}
