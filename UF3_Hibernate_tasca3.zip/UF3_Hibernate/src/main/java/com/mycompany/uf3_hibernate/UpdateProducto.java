package com.mycompany.uf3_hibernate;

import java.util.Scanner;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class UpdateProducto {

    public static void main(String[] args) {
        // Cargar la configuración desde hibernate.cfg.xml
        Configuration configuration = new Configuration();
        configuration.configure("hibernate.cfg.xml");

        // Crear la sesión de fábrica (SessionFactory)
        SessionFactory sessionFactory = configuration.buildSessionFactory();

        // Abrir una sesión de Hibernate
        try (Session session = sessionFactory.openSession()) {
            // Iniciar una transacción
            Transaction tx = session.beginTransaction();

            Scanner scanner = new Scanner(System.in);
            System.out.println("Introduce el ID del producto que quieres actualizar: ");
            long id = scanner.nextInt();

            // Obtener el producto por su ID
            Producto producto = session.get(Producto.class, id);

            // Verificar si el producto existe
            if (producto != null) {
                // Solicitar al usuario los nuevos datos para el producto
                System.out.println("Introduce el nuevo nombre del producto: ");
                String nuevoNombre = scanner.next();
                System.out.println("Introduce el nuevo precio del producto: ");
                double nuevoPrecio = scanner.nextDouble();

                // Actualizar los datos del producto
                producto.setNombre(nuevoNombre);
                producto.setPrecio(nuevoPrecio);

                // Guardar los cambios en la base de datos
                session.update(producto);

                System.out.println("Producto actualizado exitosamente.");
            } else {
                System.out.println("No se encontró ningún producto con el ID proporcionado.");
            }

            // Commit de la transacción
            tx.commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            // Cerrar la sesión de fábrica al finalizar
            sessionFactory.close();
        }
    }
}
